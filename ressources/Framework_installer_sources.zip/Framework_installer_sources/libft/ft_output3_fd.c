/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_output3_fd.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hestela <hestela@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/17 22:00:27 by hestela           #+#    #+#             */
/*   Updated: 2014/03/26 19:11:18 by hestela          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdarg.h>
#include "libft.h"

static void		ft_opt2_b(const char *form, va_list ap, int *i, int *count)
{
	int			index;

	index = 0;
	if (ft_strchr("zlhL", form[*i]))
		index = 1;
	if (ft_strchr("uid", form[*i + index]))
	{
		if (va_arg(ap, int) > 0)
			*count += ft_putchar_fd(' ', g_fd);
	}
	if (ft_strchr("feE", form[*i + index]))
	{
		if (va_arg(ap, double) > 0)
			*count += ft_putchar_fd(' ', g_fd);
	}
}

static void		ft_opt2(const char *form, va_list *ap, int *i, int *count)
{
	int			j;
	va_list		apcpy;

	j = 0;
	va_copy(apcpy, *ap);
	(*i)++;
	while (ft_strchr(".* 0123456789", form[*i]))
	{
		j++;
		(*i)++;
	}
	ft_opt2_b(form, apcpy, i, count);
	*i -= j;
	if (ft_strchr(".*+", form[*i]))
		ft_flags2fd(form, ap, i, count);
	else
		ft_flags1fd(form, ap, i, count);
}

static void		ft_opt1_b(const char *form, va_list ap, int *i, int *count)
{
	int			index;

	index = 0;
	if (ft_strchr("zlhL", form[*i]))
		index = 1;
	if (ft_strchr("uid", form[*i + index]))
	{
		if (va_arg(ap, int) > 0)
			*count += ft_putchar_fd('+', g_fd);
	}
	if (ft_strchr("feE", form[*i + index]))
	{
		if (va_arg(ap, double) > 0)
			*count += ft_putchar_fd('+', g_fd);
	}
}

static void		ft_opt1(const char *form, va_list *ap, int *i, int *count)
{
	int			j;
	va_list		apcpy;

	j = 0;
	va_copy(apcpy, *ap);
	(*i)++;
	while (ft_strchr(".* 0123456789", form[*i]))
	{
		j++;
		(*i)++;
	}
	ft_opt1_b(form, apcpy, i, count);
	*i -= j;
	if (ft_strchr(".* ", form[*i]))
		ft_flags2fd(form, ap, i, count);
	else
		ft_flags1fd(form, ap, i, count);
}

void			ft_flags3fd(const char *form, va_list *ap, int *i, int *count)
{
	if (form[*i] == '+')
		ft_opt1(form, ap, i, count);
	else if (form[*i] == ' ')
		ft_opt2(form, ap, i, count);
	else
		ft_flags4fd(form, ap, i, count);
}
