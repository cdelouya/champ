/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hestela <hestela@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/04/22 17:37:40 by hestela           #+#    #+#             */
/*   Updated: 2014/04/26 16:52:37 by hestela          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "libft.h"
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>


static char		*ft_get_location(char *executable)
{
	char		*path;
	char		*binary;
	int			len;

	binary = executable;
	len = ft_strlen(binary);
	while (binary[len - 1] != '/')
		len--;
	path = (char*)malloc(sizeof(*path) * len + 5);
	ft_bzero(path, len + 4);
	ft_strncpy(path, binary, len);
	return (path);
}

static char		*ft_get_user_library_location(char **env, char *location)
{
	char		path[1000];
	char		*user;
	int			i = 0;
	int			len;
	
	user = ft_getenv(env, "USER");
	len = ft_strlen(user);
	while (ft_strncmp(location + i, user, len))
	{
		path[i] = location[i];
		i++;
	}
	path[i] = '\0';
	return (ft_str_multi_join(3, path, user, "/Library/"));
}

static void		ft_create_framework_dir(char **env, char *libpath)
{
	char		**av;
	char		*str;
	pid_t		thread;
	
	str = ft_str_multi_join(3, "/bin/mkdir -p  ", libpath, "Frameworks");
	av = ft_strsplit(str, ' ');
	thread = fork();
	if (thread == 0)
		execve(av[0], av, env);
	else
		wait(&thread);
	free(str);
	ft_array_str_free(av);
}

static void		ft_copy_frameworks(char **env, char *libpath, char *frampath)
{
	char		**av;
	char		*str;
	pid_t		thread;

	//Copy SDL 1.2
	str = ft_str_multi_join(5, "/bin/cp -r  ", frampath, "../Frameworks/SDL.framework ", libpath, "Frameworks/");
	av = ft_strsplit(str, ' ');
	thread = fork();
	if (thread == 0)
		execve(av[0], av, env);
	else
		wait(&thread);
	free(str);
	ft_array_str_free(av);
	//Copy SDL_image 1.2
	str = ft_str_multi_join(5, "/bin/cp -r  ", frampath, "../Frameworks/SDL_image.framework ", libpath, "Frameworks/");
	av = ft_strsplit(str, ' ');
	thread = fork();
	if (thread == 0)
		execve(av[0], av, env);
	else
		wait(&thread);
	free(str);
	ft_array_str_free(av);
	//Copy SDL_ttf 1.2
	str = ft_str_multi_join(5, "/bin/cp -r  ", frampath, "../Frameworks/SDL_ttf.framework ", libpath, "Frameworks/");
	av = ft_strsplit(str, ' ');
	thread = fork();
	if (thread == 0)
		execve(av[0], av, env);
	else
		wait(&thread);
	free(str);
	ft_array_str_free(av);
}

static void		ft_launch_application(char *executable, char **env, char *path)
{
	char		**av;
	char		*str;
	pid_t		thread;
	char		*app;
	int			i;

	i = 0;
	app = executable;
	i = ft_strlen(app) - 1;
	while (app[i - 1] != '/')
		i--;
	str = ft_str_multi_join(3, path, "../Applications/", app + i);
	av = ft_strsplit(str, ' ');
	thread = fork();
	if (thread == 0)
		execve(av[0], av, env);
	else
		wait(&thread);
	ft_array_str_free(av);
	free(str);
}

int		main(int ac, char **av, char **env)
{
	ac = (int)ac;

	char		*location;
	char		*library;
	
	location = ft_get_location(av[0]);
	library = ft_get_user_library_location(env, location);
	ft_putstr(library);
	ft_create_framework_dir(env, library);
	ft_copy_frameworks(env, library, location);
	ft_launch_application(av[0], env, location);
	free(location);
	free(library);
	return (0);
}
